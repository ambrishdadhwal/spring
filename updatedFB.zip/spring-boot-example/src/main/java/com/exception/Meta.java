package com.exception;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Meta {
	private List<String> msgs;
}
