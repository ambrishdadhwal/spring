package com.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import Utilities.Buisnessresult;
import Utilities.IBusinessResult;

@ControllerAdvice
public class ExceptionHandler extends ResponseEntityExceptionHandler {
	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		IBusinessResult<Object> resObj = new Buisnessresult();
		return super.handleExceptionInternal(ex, body, headers, status, request);
	}

	@org.springframework.web.bind.annotation.ExceptionHandler({ FieldValidationException.class })
	public ResponseEntity<Object> handleBadRequest(final FieldValidationException ex, final WebRequest request) {
		IBusinessResult<Object> resObj = new Buisnessresult<>();
		Meta meta = new Meta();
		List<String> msgs = new ArrayList();
		msgs.add("error 1");
		msgs.add("error 2");
		meta.setMsgs(msgs);
		resObj.setData( meta);
		return handleExceptionInternal(ex, resObj, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
	}
}
