package com.exception;

import java.util.List;

import javax.servlet.ServletException;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FieldValidationException extends ServletException {
	private List<String> msgs;

	public FieldValidationException(List msgs) {
		super();
		this.msgs = msgs;
		this.setMsgs(msgs);
	}
}
