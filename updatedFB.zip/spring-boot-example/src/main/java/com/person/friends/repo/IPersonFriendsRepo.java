package com.person.friends.repo;

import java.util.List;

import com.model.PersonFriend;
import com.model.PersonFriendRequest;

public interface IPersonFriendsRepo {
	PersonFriend addFriend(PersonFriendRequest personRequest);

	PersonFriend removeFriend(int personID, int friendID);

	PersonFriend updateFriend(int personID, PersonFriendRequest personRequest);

	PersonFriend getFriend(int personID, int friendID);

	List<PersonFriend> getFriends(int personID);
}
