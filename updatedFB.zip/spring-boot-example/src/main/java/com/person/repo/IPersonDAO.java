package com.person.repo;

import java.util.List;

import com.model.PersonRequest;
import com.Domain.CtxMember;
import com.model.Person;

public interface IPersonDAO {
	Person getPerson(int id);

	List<Person> getPersons();

	Person addPerson(PersonRequest payeeRequest);

	Person removePerson(int id);

	Person updatePerson(PersonRequest payeeRequest, int id);
	
	List<CtxMember> getMembers(int userId);
}
