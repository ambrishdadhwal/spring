package com.person.repo;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.el.util.ReflectionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.Domain.CtxMember;
import com.model.Person;
import com.model.PersonRequest;

@Repository
public class PersonDAO implements IPersonDAO {

	static Map<Integer, Person> personMap = new HashMap<>();

	@Autowired
	protected JdbcTemplate jdbcTemplate;

	int counter;
	{
		personMap.put(1, new Person("ambrish", "rajput", 12, null, 1, null));
	}

	@Override
	public Person getPerson(int id) {
		return personMap.get(new Integer(id));
	}

	@Override
	public List<Person> getPersons() {
		return personMap.values().stream().collect(Collectors.toList());

	}

	@Override
	public Person addPerson(PersonRequest personReq) {
		int count = ++counter;
		Person person = new Person(personReq.getFname(), personReq.getLname(), personReq.getAge(), null, count, null);
		personMap.put(count, person);
		return person;
	}

	@Override
	public Person removePerson(int id) {
		Person person = personMap.get(id);
		personMap.remove(id);
		return person;
	}

	@Override
	public Person updatePerson(PersonRequest perRequest, int id) {
		Person person = personMap.get(id);
		person.setFName(perRequest.getFname());
		person.setLName(perRequest.getLname());
		person.setAge(perRequest.getAge());
		personMap.put(id, person);
		return person;
	}

	public List<CtxMember> getMembers(int id) {
		String sql = "select * from cbmember_payee_account fetch first 3 rows only";
		List<CtxMember> members = jdbcTemplate.query(sql, new MemberDetailRowCallbackHandler());
		getMember(12);
		return members;
	}

	public CtxMember getMember(int id) {
		id = 188695373;
		String sql = "select * from cbmember_payee_account fetch next 1 rows only";
		CtxMember member = jdbcTemplate.queryForObject(sql, new MemberDetailRowCallbackHandler());
		System.out.println("...,,." + member);
		return member;
	}
}

class MemberDetailRowCallbackHandler implements RowMapper<CtxMember> {

	@Override
	public CtxMember mapRow(ResultSet rs, int rowNum) throws SQLException {
		CtxMember dtoResult = null;
		dtoResult = new CtxMember();
		dtoResult.setMpaID(rs.getLong("MPA_ID") + "");
		dtoResult.setPaeID(rs.getLong("PAE_ID") + "");
		dtoResult.setMemID(rs.getLong("MEM_ID") + "");
		return dtoResult;
	}

}

class NewMapperHandling<T> implements RowMapper<T> {

	private Class<T> clazz;

	public NewMapperHandling(Class<T> clazz) {
		this.clazz = clazz;
	}

	@Override
	public T mapRow(ResultSet rs, int rowNum) throws SQLException {
		T result = null;
		try {
			result = EntityMapper.map(rs, clazz);
		} catch (Exception g) {

		}
		return null;
	}

}

class EntityMapper {
	public static <T> T map(ResultSet rs, Class<T> clazz) {
		try {
			T entity = clazz.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
}
