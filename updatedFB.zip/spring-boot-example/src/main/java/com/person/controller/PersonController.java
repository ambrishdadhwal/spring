package com.person.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Domain.CtxMember;
import com.model.Person;
import com.model.PersonRequest;
import com.person.services.IPersonService;
import com.validations.ValidateUser;

import Utilities.IBusinessResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/v1")
@Api(value = "person", tags = { "Social Network" })
@ValidateUser(validateToken = true)
public class PersonController {

	@Autowired
	IPersonService personService;
	
	

	@GetMapping(value = "/person/{id}", headers = "Accept=application/json")
	public ResponseEntity<IBusinessResult<Person>> getData(@PathVariable int id) {
		IBusinessResult<Person> person = personService.getPerson(id);
		Person p1 = person.getData();
		if (p1 == null) {
			person.setFailureReason("Data not found for this user!");
			return new ResponseEntity<>(person, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(person, HttpStatus.OK);
	}

	@GetMapping(value = "/persons", headers = "Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<IBusinessResult<List<Person>>> getData() {
		IBusinessResult<List<Person>> persons = personService.getPersons();
		return new ResponseEntity<>(persons, HttpStatus.OK);
	}
	
	@GetMapping(value = "/getMembers", headers = "Accept=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<IBusinessResult<List<CtxMember>>> getMembers() {
		IBusinessResult<List<CtxMember>> persons = personService.getMembers(12);
		return new ResponseEntity<>(persons, HttpStatus.OK);
	}

	@ApiOperation(value = "add a person", notes = "adding a person")
	@PostMapping(value = "/addPerson", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<IBusinessResult<Person>> addPerson(@RequestBody PersonRequest payeeRequest) {
		IBusinessResult<Person> person = personService.addPerson(payeeRequest);
		return new ResponseEntity<>(person, HttpStatus.OK);
	}

	@ApiOperation(value = "remove a person", notes = "remove a person")
	@DeleteMapping(value = "/removePerson", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<IBusinessResult<Person>> deletePerson(@PathVariable int id) {
		IBusinessResult<Person> person = personService.removePerson(id);
		return new ResponseEntity<>(person, HttpStatus.OK);
	}

	@ApiOperation(value = "update a person", notes = "update a person")
	@DeleteMapping(value = "/updatePerson", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<IBusinessResult<Person>> updatePerson(@RequestBody PersonRequest personRequest,
			@PathVariable int id) {
		IBusinessResult<Person> person = personService.updatePerson(personRequest,id);
		return new ResponseEntity<>(person, HttpStatus.OK);
	}
}
