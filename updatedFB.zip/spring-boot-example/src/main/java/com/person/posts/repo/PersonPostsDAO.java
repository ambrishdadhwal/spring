package com.person.posts.repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.model.PersonPost;
import com.model.PostsRequest;

@Repository
public class PersonPostsDAO implements IPersonPostsDAO {
	static Map<Integer, List<PersonPost>> personPostsMap = new HashMap<Integer, List<PersonPost>>();
	static int counter;
	static {
		List<PersonPost> list = new ArrayList<>();
		list.add(new PersonPost("post 1", "post 11"));
		list.add(new PersonPost("post 2", "post 22"));
		personPostsMap.put(++counter, list);
	}

	@Override
	public PersonPost addPersonPost(PostsRequest postsRequest, int personID) {
		PersonPost postsRequest2 = new PersonPost(postsRequest.getPostName(), postsRequest.getPostData());
		List<PersonPost> list = new ArrayList<>();
		list.add(new PersonPost("post 1", "post 11"));
		list.add(new PersonPost("post 2", "post 22"));
		list.add(postsRequest2);
		personPostsMap.put(++counter, list);
		return postsRequest2;
	}

	@Override
	public PersonPost deletePersonPost(int postID, int personID) {
		return null;
	}

	@Override
	public PersonPost updatePost(PostsRequest postsRequest, int personID) {
		return null;
	}

	@Override
	public List<PersonPost> getPersonPosts(int personID) {
		List<PersonPost> list = personPostsMap.entrySet().stream().filter(n -> n.getKey() == personID)
				.flatMap(e -> e.getValue().stream()).collect(Collectors.toList());
		return list;
	}

}
