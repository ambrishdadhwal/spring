package com.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PersonFriendRequest {
	private String fName;
	private String fLame;
	private String uName;
	private String email;
	private int id;
}
