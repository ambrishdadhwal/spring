package Utilities;

public class Buisnessresult<T> implements IBusinessResult<T> {

	private T data;
	
	
	private String reason;

	@Override
	public T getData() {
		return data;
	}

	@Override
	public void setData(T rules) {
		this.data = rules;
	}

	@Override
	public void setFailureReason(String failureReason) {
		this.reason = failureReason;

	}

	@Override
	public String getFailureReason() {

		return reason;
	}

}
