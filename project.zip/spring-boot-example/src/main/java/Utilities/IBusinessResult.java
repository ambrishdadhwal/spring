package Utilities;

public interface IBusinessResult<T> {
	public T getData();

	public void setData(T rules);

	public void setFailureReason(String failureReason);

	public String getFailureReason();
}
