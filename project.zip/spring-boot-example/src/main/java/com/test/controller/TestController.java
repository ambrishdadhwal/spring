package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.PayeeRequest;
import com.model.Person;
import com.test.services.IPersonService;
import com.validations.ValidateUser;

import Utilities.IBusinessResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@Api(value = "test", tags = { "testAPI" })
@ValidateUser(validateToken = true)
public class TestController {

	@Autowired
	IPersonService personService;

	@ApiOperation(value = "getData method", notes = "about testing", response = String.class)
	@RequestMapping("test/{id}")
	public String getData(@PathVariable("id") String id) {
		return "this is test !!... u have entered..." + id;
	}

	@ApiResponses(value = { @ApiResponse(code = 400, message = "NOT FOUND") })
	@ApiOperation(value = "getData method", notes = "about testing", response = Integer.class)
	@GetMapping(value = { "/test1", "/test2" }, headers = "Accept=application/json")
	public String getData1() {
		return "this is test 1111!!";
	}

	@GetMapping(value = "/person/{id}", headers = "Accept=application/json")
	public ResponseEntity<IBusinessResult<Person>> getData(@PathVariable int id) {
		IBusinessResult<Person> person = personService.getPerson(id);
		Person p1 = person.getData();
		return new ResponseEntity<>(person, HttpStatus.OK);
	}

	@ApiOperation(value = "add a person", notes = "adding a person")
	@PostMapping(value = "/addPerson", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<IBusinessResult<Person>> addPerson(@RequestBody PayeeRequest payeeRequest) {
		System.out.println(" fname .. " + payeeRequest.getFname() + ",,, " + payeeRequest.getLname());
		IBusinessResult<Person> person = personService.addPerson(payeeRequest);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
