package com.test.services;

import com.model.PayeeRequest;
import com.model.Person;

import Utilities.IBusinessResult;


public interface IPersonService {
	
	IBusinessResult<Person> getPerson(int id);
	IBusinessResult<Person> addPerson(PayeeRequest payeeRequest);

}
