package com.test.services;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.model.PayeeRequest;
import com.model.Person;

import Utilities.Buisnessresult;
import Utilities.IBusinessResult;

@Service
public class PersonService implements IPersonService {
	static Map<Integer, Person> personMap = new HashMap<>();

	@Override
	public IBusinessResult<Person> getPerson(int id) {
		IBusinessResult<Person> person = new Buisnessresult<>();
		person.setData(personMap.get(id));
		return person;
	}

	@Override
	public IBusinessResult<Person> addPerson(PayeeRequest payeeRequest) {
		IBusinessResult<Person> data = new Buisnessresult<>();
		
		return null;
	}

}
