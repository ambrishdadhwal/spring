package com.person.posts.services;

import java.util.List;

import com.model.PersonPost;

import Utilities.IBusinessResult;

public interface IPersonPostsService {
	public IBusinessResult<List<PersonPost>> getPosts(int personID);
}
