package com.person.posts.repo;

import java.util.List;

import com.model.PersonPost;
import com.model.PostsRequest;

public interface IPersonPostsDAO {
	PersonPost addPersonPost(PostsRequest postsRequest, int personID);

	PersonPost deletePersonPost(int postID, int personID);

	PersonPost updatePost(PostsRequest postsRequest, int personID);

	List<PersonPost> getPersonPosts(int personID);
}
