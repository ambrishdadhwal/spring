package com.person.posts.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.PersonPost;
import com.person.posts.repo.PersonPostsDAO;

import Utilities.Buisnessresult;
import Utilities.IBusinessResult;

@Service
public class PersonPostsService implements IPersonPostsService {

	@Autowired
	PersonPostsDAO personPostsDAO;

	public IBusinessResult<List<PersonPost>> getPosts(int personID) {
		IBusinessResult<List<PersonPost>> data = new Buisnessresult<>();
		List<PersonPost> personPosts = personPostsDAO.getPersonPosts(personID);
		data.setData(personPosts);
		return data;
	}

}
