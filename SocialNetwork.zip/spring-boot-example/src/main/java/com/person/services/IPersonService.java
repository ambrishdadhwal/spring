package com.person.services;

import java.util.List;

import com.model.PersonRequest;
import com.model.Person;

import Utilities.IBusinessResult;

public interface IPersonService {

	IBusinessResult<Person> getPerson(int id);

	IBusinessResult<Person> addPerson(PersonRequest payeeRequest);

	IBusinessResult<List<Person>> getPersons();

	IBusinessResult<Person> removePerson(int id);

	IBusinessResult<Person> updatePerson(PersonRequest payeeRequest, int id);
}
