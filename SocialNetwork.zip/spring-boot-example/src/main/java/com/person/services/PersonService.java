package com.person.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.PersonRequest;
import com.person.repo.PersonDAO;
import com.model.Person;

import Utilities.Buisnessresult;
import Utilities.IBusinessResult;

@Service
public class PersonService implements IPersonService {

	@Autowired
	private PersonDAO personDAO;

	@Override
	public IBusinessResult<Person> getPerson(int id) {
		IBusinessResult<Person> data = new Buisnessresult<>();
		Person peson = personDAO.getPerson(id);
		data.setData(peson);
		return data;
	}

	@Override
	public IBusinessResult<Person> addPerson(PersonRequest payeeRequest) {
		IBusinessResult<Person> data = new Buisnessresult<>();
		Person persons = personDAO.addPerson(payeeRequest);
		data.setData(persons);
		return data;
	}

	@Override
	public IBusinessResult<List<Person>> getPersons() {
		IBusinessResult<List<Person>> data = new Buisnessresult<>();
		List<Person> persons = personDAO.getPersons();
		data.setData(persons);
		return data;
	}

	@Override
	public IBusinessResult<Person> removePerson(int id) {
		IBusinessResult<Person> data = new Buisnessresult<>();
		Person persons = personDAO.removePerson(id);
		data.setData(persons);
		return data;

	}

	@Override
	public IBusinessResult<Person> updatePerson(PersonRequest payeeRequest, int id) {
		IBusinessResult<Person> data = new Buisnessresult<>();
		Person persons = personDAO.updatePerson(payeeRequest, id);
		data.setData(persons);
		return data;

	}

}
