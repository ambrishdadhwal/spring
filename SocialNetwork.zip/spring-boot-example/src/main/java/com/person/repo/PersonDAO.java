package com.person.repo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.model.Person;
import com.model.PersonRequest;

@Repository
public class PersonDAO implements IPersonDAO {

	static Map<Integer, Person> personMap = new HashMap<>();
	static int counter;

	@Override
	public Person getPerson(int id) {
		return personMap.get(new Integer(id));
	}

	@Override
	public List<Person> getPersons() {
		return personMap.values().stream().collect(Collectors.toList());

	}

	@Override
	public Person addPerson(PersonRequest personReq) {
		int count = ++counter;
		Person person = new Person(personReq.getFname(), personReq.getLname(), personReq.getAge(), null, count,null);
		personMap.put(count, person);
		return person;
	}

	@Override
	public Person removePerson(int id) {
		Person person = personMap.get(id);
		personMap.remove(id);
		return person;
	}

	@Override
	public Person updatePerson(PersonRequest perRequest, int id) {
		Person person = personMap.get(id);
		person.setFName(perRequest.getFname());
		person.setLName(perRequest.getLname());
		person.setAge(perRequest.getAge());
		personMap.put(id, person);
		return person;
	}
}
