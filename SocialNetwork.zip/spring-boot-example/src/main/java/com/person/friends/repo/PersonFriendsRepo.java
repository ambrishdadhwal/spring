package com.person.friends.repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.model.PersonFriend;
import com.model.PersonFriendRequest;

@Repository
public class PersonFriendsRepo implements IPersonFriendsRepo {
	static Map<Integer, List<PersonFriend>> friendsMap = new HashMap<Integer, List<PersonFriend>>();

	static {
		List<PersonFriend> friends = new ArrayList<PersonFriend>();
		friends.add(new PersonFriend("raj", "sharma", "coolMr", "adg@gm.com", 1));
		friends.add(new PersonFriend("anuj", "sharma", "coolX", "adg12@gm.com", 2));
		friendsMap.put(1, friends);
	}

	@Override
	public PersonFriend addFriend(PersonFriendRequest personRequest) {

		return null;
	}

	@Override
	public PersonFriend removeFriend(int personID, int friendID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonFriend updateFriend(int personID, PersonFriendRequest personRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonFriend getFriend(int personID, int friendID) {
		PersonFriend friend = friendsMap.entrySet().stream().filter(n -> n.getKey() == personID)
				.flatMap(e -> e.getValue().stream().filter(n -> n.getId() == friendID)).findAny().orElse(null);
		return friend;
	}

	@Override
	public List<PersonFriend> getFriends(int personID) {
		List<PersonFriend> friends = friendsMap.entrySet().stream().filter(n -> n.getKey() == personID)
				.flatMap(e -> e.getValue().stream()).collect(Collectors.toList());
		return friends;
	}

}
