package com.person.friends.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.PersonFriend;
import com.model.PersonFriendRequest;
import com.person.friends.repo.PersonFriendsRepo;

import Utilities.Buisnessresult;
import Utilities.IBusinessResult;

@Service
public class PersonFriendsServices implements IPersonFriendsService {

	@Autowired
	PersonFriendsRepo personFriendsRepo;

	@Override
	public IBusinessResult<PersonFriend> addFriend(PersonFriendRequest personRequest) {
		IBusinessResult<PersonFriend> data = new Buisnessresult<>();
		PersonFriend pf = personFriendsRepo.addFriend(personRequest);
		data.setData(pf);
		return data;
	}

	@Override
	public IBusinessResult<PersonFriend> removeFriend(int personID, int friendID) {
		return null;
	}

	@Override
	public IBusinessResult<PersonFriend> updateFriend(int personID, PersonFriendRequest personRequest) {
		return null;
	}

	@Override
	public IBusinessResult<PersonFriend> getFriend(int personID, int friendID) {
		IBusinessResult<PersonFriend> data = new Buisnessresult<>();
		PersonFriend friend = personFriendsRepo.getFriend(personID, friendID);
		data.setData(friend);
		return data;
	}

	@Override
	public IBusinessResult<List<PersonFriend>> getFriends(int personID) {
		IBusinessResult<List<PersonFriend>> data = new Buisnessresult<>();
		List<PersonFriend> friends = personFriendsRepo.getFriends(personID);
		data.setData(friends);
		return data;
	}

}
