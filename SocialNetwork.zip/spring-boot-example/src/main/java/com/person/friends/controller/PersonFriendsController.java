package com.person.friends.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.PersonFriend;
import com.person.friends.services.PersonFriendsServices;

import Utilities.IBusinessResult;
import io.swagger.annotations.Api;

@CrossOrigin
@RestController
@RequestMapping("/v1")
@Api(value = "person's friends", tags = { "Social Network" })
public class PersonFriendsController {

	@Autowired
	PersonFriendsServices friendsServices;

	@GetMapping(value = "/person/{personID}/friends")
	public ResponseEntity<IBusinessResult<List<PersonFriend>>> getFriends(@PathVariable int personID) {
		IBusinessResult<List<PersonFriend>> friends = friendsServices.getFriends(personID);
		return new ResponseEntity<>(friends, HttpStatus.OK);
	}

	@GetMapping(value = "/person/{personID}/friends/{friendID}")
	public ResponseEntity<IBusinessResult<PersonFriend>> getFriend(@PathVariable int personID,
			@PathVariable int friendID) {
		IBusinessResult<PersonFriend> friend = friendsServices.getFriend(personID, friendID);
		return new ResponseEntity<>(friend, HttpStatus.OK);
	}
}
