package com.person.friends.services;

import java.util.List;

import com.model.PersonFriend;
import com.model.PersonFriendRequest;

import Utilities.IBusinessResult;

public interface IPersonFriendsService {
	IBusinessResult<PersonFriend> addFriend(PersonFriendRequest personRequest);

	IBusinessResult<PersonFriend> removeFriend(int personID, int friendID);

	IBusinessResult<PersonFriend> updateFriend(int personID, PersonFriendRequest personRequest);

	IBusinessResult<PersonFriend> getFriend(int personID, int friendID);

	IBusinessResult<List<PersonFriend>> getFriends(int personID);
}
