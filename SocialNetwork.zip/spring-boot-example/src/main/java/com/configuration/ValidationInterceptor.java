package com.configuration;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Validator;

import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.validations.ValidateUser;

public class ValidationInterceptor extends HandlerInterceptorAdapter {
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println("preHandle is called");

		if (handler instanceof HandlerMethod) {
			ValidateUser validateUser = null;
			Method method = ((HandlerMethod) handler).getMethod();

			if (method.isAnnotationPresent(ValidateUser.class)) {
				System.out.println("yesy class is prsent in annotation");
				validateUser = method.getAnnotation(ValidateUser.class);
			}
			if (method.getDeclaringClass().isAnnotationPresent(ValidateUser.class)) {
				System.out.println("yesy class is prsent in getDeclaringClass annotation");
				validateUser = method.getDeclaringClass().getAnnotation(ValidateUser.class);
			}
		}
		return super.preHandle(request, response, handler);
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		System.out.println("postHandle is called");
		super.postHandle(request, response, handler, modelAndView);
	}
}
